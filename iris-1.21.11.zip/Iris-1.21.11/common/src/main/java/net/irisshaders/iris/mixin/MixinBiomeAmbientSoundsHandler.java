package net.irisshaders.iris.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import net.irisshaders.iris.mixinterface.BiomeAmbienceInterface;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.resources.sounds.BiomeAmbientSoundsHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.attribute.AmbientMoodSettings;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BiomeAmbientSoundsHandler.class)
public class MixinBiomeAmbientSoundsHandler implements BiomeAmbienceInterface {
	@Shadow
	@Final
	private LocalPlayer player;

	@Unique
	private float constantMoodiness;

	@SuppressWarnings("UnresolvedMixinReference")
	@Inject(method = {
		"method_75840",
		"lambda$tick$1"
	}, at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;getBrightness(Lnet/minecraft/world/level/LightLayer;Lnet/minecraft/core/BlockPos;)I", ordinal = 0), require = 1)
	private void calculateConstantMoodiness(Level level, AmbientMoodSettings ambientMoodSettings, CallbackInfo ci, @Local BlockPos blockPos) {
		int j = this.player.level().getBrightness(LightLayer.SKY, blockPos);
		if (j > 0) {
			this.constantMoodiness -= (float) j / (float) 15 * 0.001F;
		} else {
			this.constantMoodiness -= (float) (this.player.level().getBrightness(LightLayer.BLOCK, blockPos) - 1) / (float) ambientMoodSettings.tickDelay();
		}

		this.constantMoodiness = Mth.clamp(constantMoodiness, 0.0f, 1.0f);
	}

	@Override
	public float getConstantMood() {
		return constantMoodiness;
	}
}
